***********************************************************************
      SUBROUTINE FCN(NPAR,GRAD,FVAL,XVAL,IFLAG,Ff)
C _____________________________________________________________________ 
C |    MINUIT USER FUNCTION                                           | 
C |                                                                   | 
C |     npar    number of variable parameters                         | 
C |     g       vector of derivatives                                 | 
C |     f       function value calculated                             | 
C |     x       external parameter values (must not be changed)       | 
C |     iflag   mode flag:                                            | 
C |                         1 = initialization call                   | 
C |                         2 = gradient call => calculate derivatives| 
C |                         3 = termination call                      | 
C |                         4 = normal entry => calculate f           | 
C |                         5 = reserved                              | 
C |                        >5 => user options                         | 
C +-------------------------------------------------------------------" 
C   Global Declarations
C-----------------------
      EXTERNAL Ff,func1
      Double precision  XVAL(30)
      Double precision Fval
      common/tof/val(30),wsum,w(10)
      common/nnn/n
      dimension hx1(300),ehx1(300),bin1(300),herr1(300)
      data ientry/0/
      GOTO (10,40,30,40,40),IFLAG 
                                                                        
      RETURN                                                            
C ----------------------------------------------------------            

   10 CONTINUE
      ientry = ientry + 1
      if(ientry .eq. 1) then 
      read(21,*) nx,xmi,xma
      read(21,*) (hx1(i),i=1,nx)
      read(21,*) (bin1(i),i=1,nx)
      do 33 i=1,nx
         herr1(i) = sqrt(bin1(i))
 33      continue
      nn1 = 2
      nn2 = 100
c
      n = 7
c 
      wsum = 0.
      do 300 i=nn1,nn2
      wsum = wsum + bin1(i)
 300  continue

      do 7 k=1,npar
         val(k) = sngl(xval(k))
 7       continue
      call w_integ(nx,xmi,xma,nn1,nn2)
      write(6,*) 'integrals',(w(i),i=1,4)
      endif
   40 F = 0.
      do 8 k=1,npar
         val(k) = sngl(xval(k))
 8    continue      
      back = 1. - val(1) - val(2) - val(3)
c      write(6,*) 'back',back
      if(back .lt. 0.) then 
        f = 1.e+20
        fval = dble(f)
        return
      endif
      call w_integ(nx,xmi,xma,nn1,nn2)
            write(6,*) 'integrals',(w(i),i=1,4)
      DO 701 I=NN1,NN2
         XX = HX1(I)
         if(herr1(i) .le. 0.) go to 701
      F = F + (BIN1(I) - func1(xx))**2/(herr1(i)**2)
 701  CONTINUE
      fval = dble(f)
c      write(6,*) 'fval',fval
      RETURN
 30   CONTINUE
      fval = dble(f)
      do 9 k=1,npar
         val(k) = sngl(xval(k))
 9    continue      
      do 90 i=1,3
      y1 = val(i)*wsum
      write(6,*) 'resonance',i,y1
      write(92,*) 'resonance',i,y1
 90   continue
c
      RETURN
      END
      PROGRAM fit
C                              
      EXTERNAL FCN             
      EXTERNAL Ff
C
      open(unit=91,file='fit_dstark_nat.car',status='old')
      OPEN (UNIT=92,file='fit_dstark_nat.res',STATUS='old')
      open(unit=21,file='data.dat',status='old')
      CALL MINTIO(91,92,93)                                             
      CALL MINUIT(FCN,Ff)
      CLOSE(UNIT=91)                                                    
      CLOSE(UNIT=92)                                                    
      STOP                                                              
      END 
      subroutine w_integ(nstep,xlow,xhigh,n1,n2)
      common/tof/par(30),wsum,w(10)
      dx = (xhigh - xlow)/float(nstep)
      x = xlow + 0.5*dx
      sum0 = 0.
      sum1 = 0.
      sum2 = 0.
      sum3 = 0.
      do 10 i=1,nstep
      if(i .ge. n1 .and. i .le. n2) then
      sum0 = sum0 + f_0(x)
      sum1 = sum1 + f_1(x)
      sum2 = sum2 + f_2(x)
      sum3 = sum3 + f_3(x)
      endif
      x = x + dx
 10   continue
      w(1) = sum0
      w(2) = sum1
      w(3) = sum2
      w(4) = sum3
      return
      end
      FUNCTION Ff(X)
      Ff = 0.
      RETURN
      END
      function func1(x)
      common/tof/par(30),wsum,w(10)
      data am_dstp/2.01025/,amk0/0.497611/
      func1 = 0.
      if(x .lt. (am_dstp+amk0)) return     
      b = 1. - par(1) - par(2) - par(3)
      func1 = wsum*(b*f_0(x)/w(1)
     *     + par(1)*f_1(x)/w(2)
     *     + par(2)*f_2(x)/w(3)
     *     + par(3)*f_3(x)/w(4)      
     *     )
      return
      end
      function f_0(x)
      common/tof/par(30),wsum,w(10)
      data am_dstp/2.01025/,amk0/0.497611/
      amth = am_dstp + amk0
      f_0 = 0.
      if(x .lt. amth) return
      f_0 = ps2(x)
      return
      end
      function f_1(x)
c --- true D*2
      common/tof/par(30),wsum,w(10)
      common/nnn/n
      data am_ds0/2.5691/,g_ds0/0.0169/
c      g_ds0 = 0.02
c      am_ds0 = par(n+1)
c      g_ds0 = par(n+2)
      f_1 = bwr1(x,am_ds0,g_ds0,1)
      return
      end
      function f_2(x)
c --- true D*1
      common/tof/par(30),wsum,w(10)
      data am_ds1/2.714/,g_ds1/0.100/
      common/nnn/n
      am_ds1 = par(n+1)
      g_ds1 = par(n+2)
      f_2 = bwr1(x,am_ds1,g_ds1,1)
      return
      end
      function f_3(x)
c --- New 2.6
      common/tof/par(30),wsum,w(10)
      common/nnn/n
      data am_ds2/3.044/,g_ds2/0.090/
      am_ds2 = par(n+3)
      g_ds2 = par(n+4)      
c      am_dstar0 = par(n+4)
      f_3 = bwr1(x,am_ds2,g_ds2,1)
      return
      end
      FUNCTION bwr1(e,w,g,l)
c benitez
        DATA CHOP/6./
      dimension am(4),rxx(2)
      data am/2.01025,0.497611,5.27950,3.096916/
      data rxx/2.0,1.5/
      rx = rxx(1)
      w1 = am(1)
      w2 = am(2)
1     M=2*L
c      IF(ABS(E-W).GT.CHOP*G) GO TO 2
      IF (E-W1-W2.LT.0.) GO TO 2
      p0 = phs(w,w1,w2)
      p = phs(e,w1,w2)
      q0 = w*p0
      q = e*p

c
c ---   Blatt-Weisskopf form factors
c
      if(l .eq. 0) then
         rho = 1.
         rho0 = 1.
      endif
      if(l .eq. 1) then
        rho = sqrt((1 + (rx*q)**2))
        rho0 = sqrt((1 + (rx*q0)**2))
      endif
      if(l .eq. 2) then
        rho = sqrt((9. + 3*(rx*q)**2 + (rx*q)**4))
        rho0 = sqrt((9. + 3*(rx*q0)**2 + (rx*q0)**4))
      endif
      fr = (rho0/rho)**2
      anum = e*p*(q/q0)**M*fr
      GM=G*(p/p0)*(Q/Q0)**M*fr
      RDEN = (w**2 - e**2)**2+(w*gm)**2
      bwr1 = anum/rden
      RETURN
 2    continue
      bwr1 = 0.
      RETURN
      end
      FUNCTION ALAM(X,Y,Z)
      ALAM = X**2 + Y**2 + Z**2 - 2.*X*Y - 2.*X*Z - 2.*Y*Z
      RETURN
      END
      function phs(x,am1,am2)
      a = x**2 - (am1+am2)**2
      b = x**2 - (am1-am2)**2
      phs = sqrt(a*b)/(2*x)
      return
      end

      function ps2(x)
c benitez
      common/tof/par(30),wsum,w(10)
      common/nnn/nn
      data am_dstp/2.01025/,amk0/0.497611/
      n = nn - 3
      ps2 = 0.
      if(x .lt. (am_dstp+amk0)) return
      q = phs(x,am_dstp,amk0)
      x0 = par(n) 
      d1 = par(n+1) + 2*x0*(par(n+2) - par(n+3)) 
      d0 = 
     * x0*(par(n+1) - d1) + x0*x0*(par(n+2) - par(n+3)) 
      fac1 = exp(par(n+1)*x + par(n+2)*x*x)
      fac2 = exp(d0 + d1*x + par(n+3)*x*x)
      if(x .lt. x0) ps2 = q*fac1
      if(x .ge. x0) ps2 = q*fac2 
      return
      end 
