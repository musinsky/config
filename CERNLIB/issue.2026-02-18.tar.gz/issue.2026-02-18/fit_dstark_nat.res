 ***************************************************************************
  MINUIT RELEASE 96.03  INITIALIZED.   DIMENSIONS 100/ 50  EPSMAC=  0.89E-15
 ***************************************************************************
                          MINUIT DATA BLOCK NO.   1
 ***************************************************************************
 ENTER MINUIT TITLE, or "SET INPUT n" : 
 ENTER MINUIT TITLE, or "SET INPUT n" : 
 >>>       d0 fit  1        <<<                    
 ******************************************************************************
 ENTER MINUIT PARAMETER DEFINITION:     
 ENTER MINUIT PARAMETER DEFINITION:     
     1 'c1        '   0.10000      0.10000E-02    0.10000E-04   1.0000    
 ENTER MINUIT PARAMETER DEFINITION:     
     2 'c2        '   0.70000E-01  0.20000E-02    0.10000E-04   1.0000    
 ENTER MINUIT PARAMETER DEFINITION:     
     3 'c3        '   0.50000E-01  0.20000E-02    0.10000E-04   1.0000    
 ENTER MINUIT PARAMETER DEFINITION:     
     4 'x0        '    3.0700      0.10000E-01     2.2000       3.5000    
 ENTER MINUIT PARAMETER DEFINITION:     
     5 'c         '    1.0100      0.10000        -1000.0       1000.0    
 ENTER MINUIT PARAMETER DEFINITION:     
     6 'd         '  -0.90000      0.10000        -1000.0       1000.0    
 ENTER MINUIT PARAMETER DEFINITION:     
     7 'e         '    3.0000      0.10000        -1000.0       1000.0    
 ENTER MINUIT PARAMETER DEFINITION:     
     8 'm_ds1     '    2.7200      0.10000E-01     2.6000       2.8000    
 ENTER MINUIT PARAMETER DEFINITION:     
     9 'g_ds1     '   0.80000E-01  0.10000E-01    0.10000E-01  0.20000    
 ENTER MINUIT PARAMETER DEFINITION:     
    10 'm_ds2     '    2.8200      0.10000E-01     2.7000       2.9000    
 ENTER MINUIT PARAMETER DEFINITION:     
    11 'g_ds2     '   0.10000      0.10000E-01    0.50000E-01  0.20000    
 ENTER MINUIT PARAMETER DEFINITION:     

 MINUIT: FIRST CALL TO USER FUNCTION, WITH IFLAG=1

 FCN=   183.3706     FROM PARAMETR  STATUS=RESET          2 CALLS        2 TOTAL
                     EDM= unknown      STRATEGY= 1      NO ERROR MATRIX       

  EXT PARAMETER               CURRENT GUESS      PHYSICAL LIMITS       
  NO.   NAME        VALUE          ERROR       NEGATIVE      POSITIVE  
   1    c1         0.10000       0.10000E-02   0.10000E-04    1.0000    
   2    c2         0.70000E-01   0.20000E-02   0.10000E-04    1.0000    
   3    c3         0.50000E-01   0.20000E-02   0.10000E-04    1.0000    
   4    x0          3.0700       0.10000E-01    2.2000        3.5000    
   5    c           1.0100       0.10000       -1000.0        1000.0    
   6    d         -0.90000       0.10000       -1000.0        1000.0    
   7    e           3.0000       0.10000       -1000.0        1000.0    
   8    m_ds1       2.7200       0.10000E-01    2.6000        2.8000    
   9    g_ds1      0.80000E-01   0.10000E-01   0.10000E-01   0.20000    
  10    m_ds2       2.8200       0.10000E-01    2.7000        2.9000    
  11    g_ds2      0.10000       0.10000E-01   0.50000E-01   0.20000    
 ENTER MINUIT COMMAND:                  
 **********
 **    1 **SET ERR    1.000    
 **********
 ENTER MINUIT COMMAND:                  
 **********
 **    2 **SIMPLEX 
 **********
 START SIMPLEX MINIMIZATION.    CONVERGENCE WHEN EDM .LT.  0.10E+00

 FCN=   153.9620     FROM SIMPLEX   STATUS=PROGRESS      32 CALLS       34 TOTAL
                     EDM=  0.29E+02    STRATEGY= 1      NO ERROR MATRIX       

  EXT PARAMETER               CURRENT GUESS      PHYSICAL LIMITS       
  NO.   NAME        VALUE          ERROR       NEGATIVE      POSITIVE  
   1    c1         0.98406E-01   0.10000E-02   0.10000E-04    1.0000    
   2    c2         0.59960E-01   0.20000E-02   0.10000E-04    1.0000    
   3    c3         0.52019E-01   0.20000E-02   0.10000E-04    1.0000    
   4    x0          3.0173       0.10000E-01    2.2000        3.5000    
   5    c           1.1100       0.10000       -1000.0        1000.0    
   6    d         -0.94000       0.10000       -1000.0        1000.0    
   7    e           3.4000       0.10000       -1000.0        1000.0    
   8    m_ds1       2.7299       0.10000E-01    2.6000        2.8000    
   9    g_ds1      0.80000E-01   0.10000E-01   0.10000E-01   0.20000    
  10    m_ds2       2.8200       0.10000E-01    2.7000        2.9000    
  11    g_ds2      0.10000       0.10000E-01   0.50000E-01   0.20000    
 SIMPLEX MINIMIZATION HAS CONVERGED.

 FCN=   147.1072     FROM SIMPLEX   STATUS=PROGRESS     245 CALLS      247 TOTAL
                     EDM=  0.11E+00    STRATEGY= 1      NO ERROR MATRIX       

  EXT PARAMETER               CURRENT GUESS      PHYSICAL LIMITS       
  NO.   NAME        VALUE          ERROR       NEGATIVE      POSITIVE  
   1    c1         0.98698E-01   0.10000E-02   0.10000E-04    1.0000    
   2    c2         0.58902E-01   0.20000E-02   0.10000E-04    1.0000    
   3    c3         0.52440E-01   0.20000E-02   0.10000E-04    1.0000    
   4    x0          3.0333       0.10000E-01    2.2000        3.5000    
   5    c          0.98395       0.10000       -1000.0        1000.0    
   6    d         -0.88759       0.10000       -1000.0        1000.0    
   7    e           3.2512       0.10000       -1000.0        1000.0    
   8    m_ds1       2.7236       0.10000E-01    2.6000        2.8000    
   9    g_ds1      0.51218E-01   0.10000E-01   0.10000E-01   0.20000    
  10    m_ds2       2.8228       0.10000E-01    2.7000        2.9000    
  11    g_ds2      0.65743E-01   0.10000E-01   0.50000E-01   0.20000    
 ENTER MINUIT COMMAND:                  
 **********
 **    3 **MIGRAD 
 **********
 START MIGRAD MINIMIZATION.  STRATEGY 1.  CONVERGENCE WHEN EDM .LT. 0.10E-03

 FCN=   146.7565     FROM MIGRAD    STATUS=INITIATE     321 CALLS      568 TOTAL
                     EDM= unknown      STRATEGY= 1      NO ERROR MATRIX       

  EXT PARAMETER               CURRENT GUESS       STEP         FIRST   
  NO.   NAME        VALUE          ERROR          SIZE      DERIVATIVE 
   1    c1         0.10270       0.10000E-02    0.0000       -3.4843    
   2    c2         0.58902E-01   0.20000E-02    0.0000       -4.6969    
   3    c3         0.55102E-01   0.20000E-02    0.0000      -0.31815    
   4    x0          3.0331       0.10000E-01   0.24811E-06   -818.45    
   5    c          0.99038       0.10000        0.0000       -16155.    
   6    d         -0.88759       0.10000        0.0000      -0.30645E+06
   7    e           3.2512       0.10000        0.0000       0.13287E+06
   8    m_ds1       2.7236       0.10000E-01    0.0000       -1.4669    
   9    g_ds1      0.51218E-01   0.10000E-01    0.0000        1.6525    
  10    m_ds2       2.8228       0.10000E-01    0.0000       -1.8365    
  11    g_ds2      0.65743E-01   0.10000E-01    0.0000      -0.19508    
 MIGRAD FAILS TO FIND IMPROVEMENT
 MINUIT WARNING IN HESSE   
 ============== Negative diagonal element  4 in Error Matrix
 MINUIT WARNING IN HESSE   
 ==============     0.14E+10 added to diagonal of error matrix
 EIGENVALUES OF SECOND-DERIVATIVE MATRIX:
        -0.9836E+05 -0.1449E+01  0.9993E+00  0.1000E+01  0.1000E+01  0.1000E+01
         0.1000E+01  0.1000E+01  0.1000E+01  0.2120E+01  0.9836E+05
 MINUIT WARNING IN HESSE   
 ============== MATRIX FORCED POS-DEF BY ADDING   98454.     TO DIAGONAL.

 FCN=   146.7337     FROM HESSE     STATUS=NOT POSDEF   122 CALLS      970 TOTAL
                     EDM=  0.71E+02    STRATEGY= 1      ERR MATRIX NOT POS-DEF

  EXT PARAMETER                APPROXIMATE        STEP         FIRST   
  NO.   NAME        VALUE          ERROR          SIZE      DERIVATIVE 
   1    c1         0.10270       0.37449E-07   0.72296E-05   -52.765    
   2    c2         0.59780E-01   0.28722E-07   0.61442E-04   -2.4835    
   3    c3         0.55078E-01   0.27635E-07   0.55866E-04   -4.0970    
   4    x0          3.0331       0.62794E-01   0.45765E-06   -166.71    
   5    c          0.99038       0.31287E-05   0.19771E-08  -0.10612E+07
   6    d         -0.88759       0.27407E-04   0.35940E-08  -0.15921E+06
   7    e           3.2512       0.62912E-05   0.15503E-08   -59055.    
   8    m_ds1       2.7239       0.11762E-07   0.35210E-03  -0.54171    
   9    g_ds1      0.50860E-01   0.94567E-08   0.43161E-03  -0.17677    
  10    m_ds2       2.8235       0.11776E-07   0.24853E-02  -0.30477    
  11    g_ds2      0.66387E-01   0.56685E-08   0.62196E-03   0.18400    
 MIGRAD FAILS TO FIND IMPROVEMENT
 MIGRAD TERMINATED WITHOUT CONVERGENCE.

 FCN=   146.7337     FROM MIGRAD    STATUS=FAILED       734 CALLS      981 TOTAL
                     EDM=  0.71E+02    STRATEGY= 1      ERR MATRIX NOT POS-DEF

  EXT PARAMETER                APPROXIMATE        STEP         FIRST   
  NO.   NAME        VALUE          ERROR          SIZE      DERIVATIVE 
   1    c1         0.10270       0.37449E-07    0.0000       -52.765    
   2    c2         0.59780E-01   0.28722E-07    0.0000       -2.4835    
   3    c3         0.55078E-01   0.27635E-07    0.0000       -4.0970    
   4    x0          3.0331       0.62794E-01    0.0000       -166.71    
   5    c          0.99038       0.31287E-05   -0.0000      -0.10612E+07
   6    d         -0.88759       0.27407E-04   -0.0000      -0.15921E+06
   7    e           3.2512       0.62912E-05   -0.0000       -59055.    
   8    m_ds1       2.7239       0.11762E-07    0.0000      -0.54171    
   9    g_ds1      0.50860E-01   0.94567E-08    0.0000      -0.17677    
  10    m_ds2       2.8235       0.11776E-07    0.0000      -0.30477    
  11    g_ds2      0.66387E-01   0.56685E-08    0.0000       0.18400    

 EXTERNAL ERROR MATRIX.    NDIM=  50    NPAR= 11    ERR DEF=  1.00    
 ELEMENTS ABOVE DIAGONAL ARE NOT PRINTED.
  0.140E-14
  0.345E-17 0.825E-15
  0.219E-17 0.144E-18 0.764E-15
  0.455E-09 0.299E-10 0.190E-10 0.396E-02
 -0.222E-13-0.146E-14-0.926E-15-0.193E-06 0.979E-11
 -0.198E-12-0.130E-13-0.826E-14-0.172E-05 0.838E-10 0.751E-09
 -0.455E-13-0.299E-14-0.190E-14-0.395E-06 0.192E-10 0.172E-09 0.396E-10
  0.197E-18 0.130E-19 0.823E-20 0.171E-11-0.834E-16-0.744E-15-0.171E-15
  0.138E-15
  0.129E-18 0.850E-20 0.540E-20 0.112E-11-0.547E-16-0.488E-15-0.112E-15
  0.486E-21 0.894E-16
  0.210E-19 0.138E-20 0.875E-21 0.182E-12-0.887E-17-0.792E-16-0.182E-16
  0.788E-22 0.517E-22 0.139E-15
  0.108E-18 0.707E-20 0.449E-20 0.934E-12-0.455E-16-0.406E-15-0.932E-16
  0.404E-21 0.265E-21 0.430E-22 0.321E-16
 ERR MATRIX NOT POS-DEF

 PARAMETER  CORRELATION COEFFICIENTS
       NO.  GLOBAL     1     2     3     4     5     6     7     8     9    10
        1  0.19333  1.000 0.003 0.002 0.193-0.189-0.193-0.193 0.000 0.000 0.000
        2  0.01657  0.003 1.000 0.000 0.017-0.016-0.017-0.017 0.000 0.000 0.000
        3  0.01094  0.002 0.000 1.000 0.011-0.011-0.011-0.011 0.000 0.000 0.000
        4  0.99900  0.193 0.017 0.011 1.000-0.979-0.998-0.998 0.002 0.002 0.000
        5  0.97934 -0.189-0.016-0.011-0.979 1.000 0.977 0.977-0.002-0.002-0.000
        6  0.99771 -0.193-0.017-0.011-0.998 0.977 1.000 0.996-0.002-0.002-0.000
        7  0.99807 -0.193-0.017-0.011-0.998 0.977 0.996 1.000-0.002-0.002-0.000
        8  0.00231  0.000 0.000 0.000 0.002-0.002-0.002-0.002 1.000 0.000 0.000
        9  0.00189  0.000 0.000 0.000 0.002-0.002-0.002-0.002 0.000 1.000 0.000
       10  0.00025  0.000 0.000 0.000 0.000-0.000-0.000-0.000 0.000 0.000 1.000
       11  0.00262  0.001 0.000 0.000 0.003-0.003-0.003-0.003 0.000 0.000 0.000
                    1.000
 ERR MATRIX NOT POS-DEF
 ENTER MINUIT COMMAND:                  
 **********
 **    4 **HESSE 
 **********
 EIGENVALUES OF SECOND-DERIVATIVE MATRIX:
        -0.2692E-01  0.1090E+00  0.1265E+00  0.1499E+00  0.3032E+00  0.7884E+00
         0.9627E+00  0.1146E+01  0.1519E+01  0.1963E+01  0.3960E+01
 MINUIT WARNING IN HESSE   
 ============== MATRIX FORCED POS-DEF BY ADDING  0.30880E-01 TO DIAGONAL.

 FCN=   146.7337     FROM HESSE     STATUS=NOT POSDEF   190 CALLS     1171 TOTAL
                     EDM=  0.13E+00    STRATEGY= 1      ERR MATRIX NOT POS-DEF

  EXT PARAMETER                APPROXIMATE     INTERNAL      INTERNAL  
  NO.   NAME        VALUE          ERROR       STEP SIZE       VALUE   
   1    c1         0.10270       0.96477E-02   0.47530E-02  -0.91837    
   2    c2         0.59780E-01   0.18211E-01   0.76494E-02   -1.0768    
   3    c3         0.55078E-01   0.25059E-01   0.81433E-02   -1.0970    
   4    x0          3.0331       0.64502E-01   0.91530E-03   0.28562    
   5    c          0.99038       0.49550       0.79084E-06   0.99038E-03
   6    d         -0.88759       0.99062E-01   0.14376E-05  -0.88759E-03
   7    e           3.2512       0.50359       0.77515E-05   0.32512E-02
   8    m_ds1       2.7239       0.66667E-02   0.12011E-01   0.24165    
   9    g_ds1      0.50860E-01   0.14753E-01   0.23334E-01  -0.60638    
  10    m_ds2       2.8235       0.90630E-02   0.13800E-01   0.23701    
  11    g_ds2      0.66387E-01   0.35378E-01   0.67405E-01  -0.89708    

 EXTERNAL ERROR MATRIX.    NDIM=  50    NPAR= 11    ERR DEF=  1.00    
 ELEMENTS ABOVE DIAGONAL ARE NOT PRINTED.
  0.931E-04
  0.764E-04 0.332E-03
  0.103E-03 0.116E-03 0.631E-03
 -0.229E-03-0.532E-03-0.105E-02 0.418E-02
  0.219E-02 0.495E-02 0.774E-02-0.291E-01 0.246E+00
 -0.345E-03-0.815E-03-0.156E-02 0.606E-02-0.475E-01 0.981E-02
 -0.217E-02-0.479E-02-0.678E-02 0.289E-01-0.220E+00 0.410E-01 0.254E+00
 -0.544E-05 0.496E-05-0.465E-04 0.214E-05-0.170E-05-0.119E-04 0.383E-04
  0.445E-04
  0.443E-04 0.205E-03 0.589E-04-0.363E-03 0.330E-02-0.574E-03-0.309E-02
  0.112E-04 0.220E-03
  0.251E-04 0.691E-04 0.102E-03-0.308E-03 0.240E-02-0.483E-03-0.209E-02
  0.429E-05 0.467E-04 0.824E-04
  0.151E-03 0.199E-03 0.898E-03-0.167E-02 0.125E-01-0.256E-02-0.107E-01
 -0.549E-04 0.128E-03 0.197E-03 0.161E-02
 ERR MATRIX NOT POS-DEF

 PARAMETER  CORRELATION COEFFICIENTS
       NO.  GLOBAL     1     2     3     4     5     6     7     8     9    10
        1  0.62986  1.000 0.434 0.424-0.367 0.459-0.361-0.446-0.084 0.309 0.286
        2  0.84002  0.434 1.000 0.254-0.452 0.548-0.451-0.522 0.041 0.757 0.418
        3  0.91427  0.424 0.254 1.000-0.644 0.622-0.626-0.537-0.277 0.158 0.447
        4  0.98861 -0.367-0.452-0.644 1.000-0.908 0.947 0.889 0.005-0.379-0.525
        5  0.99420  0.459 0.548 0.622-0.908 1.000-0.968-0.881-0.001 0.449 0.534
        6  0.99565 -0.361-0.451-0.626 0.947-0.968 1.000 0.823-0.018-0.390-0.537
        7  0.97409 -0.446-0.522-0.537 0.889-0.881 0.823 1.000 0.011-0.413-0.457
        8  0.40550 -0.084 0.041-0.277 0.005-0.001-0.018 0.011 1.000 0.114 0.071
        9  0.76893  0.309 0.757 0.158-0.379 0.449-0.390-0.413 0.114 1.000 0.347
       10  0.64819  0.286 0.418 0.447-0.525 0.534-0.537-0.457 0.071 0.347 1.000
       11  0.90899  0.390 0.273 0.891-0.646 0.630-0.645-0.532-0.205 0.216 0.540
                    1.000
 ERR MATRIX NOT POS-DEF
 ENTER MINUIT COMMAND:                  
 **********
 **    5 **END RETURN 
 **********

 CALL TO USER FUNCTION WITH IFLAG = 3

 resonance           1   365.317596    
 resonance           2   212.638016    
 resonance           3   195.913376    
 ..........MINUIT TERMINATED AND RETURNS TO USER PROGRAM.            
